package com.pavel.jinn;

import com.loopj.android.http.*;
import com.pavel.jinn.Adapter.WishAdapter;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.recyclerview.widget.RecyclerView;

import android.Manifest;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import cz.msebera.android.httpclient.Header;

public class MainActivity extends AppCompatActivity {
    private List<Wish> wishList = new ArrayList<>();

    public double distance(
            double x1,
            double y1,
            double x2,
            double y2) {
        return Math.sqrt((y2 - y1) * (y2 - y1) + (x2 - x1) * (x2 - x1));
    }

    private WishAdapter wishAdapter;
    private RecyclerView wishesRecyclerView;
    TextView tvd1, tvd2, tvr1, tvr2;
    private LocationManager locationManager;
    String coordsOrigin;
    EditText et;
    private LocationListener locationListener = new LocationListener() {
        @Override
        public void onLocationChanged(Location location) {
            String longitude;
            String latitude;
            latitude = "" + location.getLatitude();
            longitude = "" + location.getLongitude();
            coordsOrigin = latitude + ":" + longitude;
        }

        @Override
        public void onStatusChanged(String provider, int status, Bundle extras) {
        }

        @Override
        public void onProviderEnabled(String provider) {

        }

        @Override
        public void onProviderDisabled(String provider) {
        }
    };

    String getGPSCoords() {
        LocationManager locationManager = (LocationManager) getSystemService(LOCATION_SERVICE);

        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{
                    Manifest.permission.ACCESS_FINE_LOCATION,
                    Manifest.permission.ACCESS_COARSE_LOCATION}, 1);
        }
        locationManager.requestSingleUpdate(LocationManager.NETWORK_PROVIDER, locationListener, null);
        locationManager.requestSingleUpdate(LocationManager.GPS_PROVIDER, locationListener, null);
        return coordsOrigin;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        tvr1 = findViewById(R.id.distance1);
        tvr2 = findViewById(R.id.distance2);
        et = findViewById(R.id.edittext);
        tvd1 = findViewById(R.id.description1);
        tvd2 = findViewById(R.id.description2);
        locationManager = (LocationManager) getSystemService(LOCATION_SERVICE);
    }

    public void request_nearest(View v) {
        final List<Wish> wishList = new ArrayList<>();
        coordsOrigin = et.getText().toString();
        final AsyncHttpClient client = new AsyncHttpClient();
        client.get("http://188.19.71.67:50253/getnearest:" + coordsOrigin, new AsyncHttpResponseHandler() {
            @Override
            public void onSuccess(int statusCode, Header[] headers, byte[] response) {
                String resp = null;
                try {
                    resp = new String(response, "UTF-8");
                } catch (UnsupportedEncodingException e) {
                    e.printStackTrace();
                }
                for (String cur : resp.split("]")) {
                    cur = cur.replace("[", "");
                    cur = cur.replace("'", "");
                    Wish wish = new Wish();
                    System.out.println(cur);
                    System.out.println(cur.split(", ")[0]);
//                    wish.id = Integer.parseInt(cur.split(",")[0]);
                    wish.description = cur.split(", ")[1];
                    DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
//                    try {
//                        Date d = dateFormat.parse(cur.split(",")[2]);
//                        wish.create = d;
//                        Date d2 = dateFormat.parse(cur.split(",")[3]);
//                        wish.expire = d2;
//                    } catch (ParseException e) {
//                        e.printStackTrace();
//                    }
                    wish.lat = Float.parseFloat(cur.split(",")[4]);
                    wish.lng = Float.parseFloat(cur.split(",")[5]);
                    wishList.add(wish);
                }
                tvd1.setText(wishList.get(0).description);
                tvd2.setText(wishList.get(1).description);

                String curlat = coordsOrigin.split(":")[0];
                String curlng = coordsOrigin.split(":")[1];
                tvr1.setText(String.valueOf(distance(Integer.parseInt(curlat), Integer.parseInt(curlng), wishList.get(0).lat, wishList.get(0).lng)));
                tvr2.setText(String.valueOf(distance(Integer.parseInt(curlat), Integer.parseInt(curlng), wishList.get(1).lat, wishList.get(1).lng)));
            }

            @Override
            public void onFailure(int statusCode, Header[] headers, byte[] responseBody, Throwable error) {
            }
        });
    }

}