package com.pavel.jinn;

import java.sql.Time;
import java.util.Date;

public class Wish {
    public int id;
    public String description;
    public Date create;
    public Date expire;
    public float lat;
    public float lng;
}
