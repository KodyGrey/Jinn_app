package com.pavel.jinn.Adapter;

import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.AsyncHttpResponseHandler;
import com.pavel.jinn.R;
import com.pavel.jinn.Wish;

import java.io.UnsupportedEncodingException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import cz.msebera.android.httpclient.Header;

public class WishAdapter extends RecyclerView.Adapter<WishAdapter.WishViewHolder> {
    private List<Wish> wishList = new ArrayList<>();

    public void request_nearest(double lat, double lng) {
        final AsyncHttpClient client = new AsyncHttpClient();
        client.get("http://188.19.71.67:50253/getnearest:" + lat + ":" + lng, new AsyncHttpResponseHandler() {
            @Override
            public void onSuccess(int statusCode, Header[] headers, byte[] response) {
                String resp = null;
                try {
                    resp = new String(response, "UTF-8");
                } catch (UnsupportedEncodingException e) {
                    e.printStackTrace();
                }
                for (String cur : resp.split("],")) {
                    cur = cur.replace("[[", "");
                    Wish wish = new Wish();
                    wish.id = Integer.parseInt(cur.split(",")[0]);
                    wish.description = cur.split(",")[1];

                    DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
                    try {
                        Date d = dateFormat.parse(cur.split(",")[2]);
                        wish.create = d;
                        Date d2 = dateFormat.parse(cur.split(",")[3]);
                        wish.expire = d2;
                    } catch (ParseException e) {
                        e.printStackTrace();
                    }
                    wish.lat = Float.parseFloat(cur.split(",")[4]);
                    wish.lng = Float.parseFloat(cur.split(",")[5]);
                    wishList.add(wish);
                }
            }

            @Override
            public void onFailure(int statusCode, Header[] headers, byte[] responseBody, Throwable error) {
            }
        });
    }

    @NonNull
    @Override
    public WishViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        request_nearest(100, 100);
        return null;
    }

    @Override
    public void onBindViewHolder(@NonNull WishViewHolder holder, int position) {
        holder.bind(wishList.get(position));
    }

    @Override
    public int getItemCount() {
        return wishList.size();
    }

    class WishViewHolder extends RecyclerView.ViewHolder {
        private TextView descriptionTextView;
        private TextView distanceTextView;
        CardView cv;

        public void bind(Wish wish) {
            descriptionTextView.setText(wish.description);
            distanceTextView.setText(wish.description);
        }

        public WishViewHolder(View itemView) {
            super(itemView);
            cv = itemView.findViewById(R.id.cv);
            descriptionTextView = itemView.findViewById(R.id.description);
            distanceTextView = itemView.findViewById(R.id.distance);

        }
    }
}


