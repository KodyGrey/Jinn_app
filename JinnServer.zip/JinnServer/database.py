import sqlite3
from dateutil import parser
import datetime

DATABASE_LOCATION = "c:\sqlite\database.db"


def get_nearest(location_lat=0, location_lng=0):
    conn = sqlite3.connect(DATABASE_LOCATION)
    cursor = conn.cursor()
    cursor.execute(
        "SELECT * FROM wishes ORDER BY (( " + str(location_lat) + "-lat)*( " + str(location_lat) + "-lat)) + (( " + str(
            location_lng) + " - long)*( " + str(location_lng) + " - long)) ASC")
    results = cursor.fetchall()
    conn.close()
    return results


def write_wish(wish):
    conn = sqlite3.connect(DATABASE_LOCATION)
    cursor = conn.cursor()
    create_dt = parser.parse(wish[1])
    expire_dt = parser.parse(wish[2])
    cursor.execute(
        "insert into wishes (description, create_dt, expire_dt, lat, long) values (?,?,?,?,?)", (wish[0], create_dt,
                                                                                                 expire_dt, wish[3],
                                                                                                 wish[4]))
    conn.commit()
    conn.close()
    return 'ok'


def do_cleanup():
    conn = sqlite3.connect(DATABASE_LOCATION)
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM wishes")
    results = cursor.fetchall()
    counter = 0
    for cur in results:
        if parser.parse(cur[3]) < datetime.datetime.now():
            cursor.execute("DELETE FROM wishes WHERE id = " + str(cur[0]))
            counter +=1
    print("[CLEANUP]: Removed " + str(counter) + " wishes")
    conn.commit()
    conn.close()

#  http://188.19.71.67:50253/writewish:zakladku:11.14.2020:14.14.2020:0.1111:0.2333
