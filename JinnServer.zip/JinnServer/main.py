from http.server import BaseHTTPRequestHandler, HTTPServer
import database
import json
import yaml

def list_to_str(list):
    stroka = ''
    for cur in list:
        stroka += str(cur)

    stroka.replace(')(', '),(')
    print(stroka)
    return stroka


def do_request(line):
    request = line.split('/')[1].split('HTTP')[0]
    if request.startswith('getnearest'):
        request.replace('getnearest', '')
        lat = request.split(':')[1]
        long = request.split(':')[2]
        list_dump = json.dumps(database.get_nearest(lat, long))
        yaml_dump = yaml.safe_load(list_dump)
        return list_to_str(yaml_dump).encode()

    if request.startswith('writewish'):
        request.replace('getnearest', '')
        description = request.split(':')[1]
        create_dt = request.split(':')[2]
        expire_dt = request.split(':')[3]
        lat = request.split(':')[4]
        long = request.split(':')[5]
        return list_to_str(database.write_wish((description, create_dt, expire_dt, lat, long))).encode()


class HandleRequests(BaseHTTPRequestHandler):
    def _set_headers(self):
        self.send_response(200)
        self.send_header('Content-type', 'text/html')
        self.end_headers()

    def do_GET(self):
        self._set_headers()
        request = self.requestline
        print(request)
        db_ans = do_request(request)
        print(db_ans)
        if db_ans is not None:
            self.wfile.write(db_ans)
        self.send_response(200)

    def do_POST(self):
        '''Reads post request body'''
        self._set_headers()
        content_len = int(self.headers.getheader('content-length', 0))
        post_body = self.rfile.read(content_len)
        self.wfile.write("received post request:<br>{}".format(post_body))

    def do_PUT(self):
        self.do_POST()


host = ''
port = 50253
HTTPServer((host, port), HandleRequests).serve_forever()
